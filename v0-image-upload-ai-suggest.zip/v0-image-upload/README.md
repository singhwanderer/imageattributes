# v0-image-upload-enhancement

This is a [Next.js](https://nextjs.org) project bootstrapped with [v0](https://v0.app).

## Built with v0

This repository is linked to a [v0](https://v0.app) project. You can continue developing by visiting the link below -- start new chats to make changes, and v0 will push commits directly to this repo. Every merge to `main` will automatically deploy.

[Continue working on v0 →](https://v0.app/chat/projects/prj_X3SSPXgUhWceGfC9NfJEABpmodM5)

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

## Learn More

To learn more, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.
- [v0 Documentation](https://v0.app/docs) - learn about v0 and how to use it.

<a href="https://v0.app/chat/api/kiro/clone/singhwanderer/v0-image-upload-enhancement" alt="Open in Kiro"><img src="https://pdgvvgmkdvyeydso.public.blob.vercel-storage.com/open%20in%20kiro.svg?sanitize=true" /></a>

## AI metadata suggestions (demo)

Step 2 of the upload wizard pre-fills attributes from the uploaded image:
orientation, facing, angle, image style, and description come from a
server-side Gemini call (`app/api/suggest-metadata/route.ts`); height and
width are read deterministically from the file. Extended product attributes
the model can ground in the image appear in an editable section below the
form. Business-choice fields (image type, purpose, location type, clipping
path) are never AI-filled by design.

Setup: set `GEMINI_API_KEY` in the deployment environment (Vercel project
env vars, or `.env.local` for local dev). The key never reaches the browser.

Fallback: if the key is missing, expired, or the call fails, the wizard
runs exactly as before — fully manual, with a one-line notice. AI is
progressive enhancement, never a gate.

Scope note: extended attributes here are additional demo scope; alignment
with the AI Attribute Enrichment flow is deferred deliberately.
